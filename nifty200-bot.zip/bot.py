import yfinance as yf
import ta
import pandas as pd
import requests
import os

# Load secrets from environment
TOKEN = os.environ['TELEGRAM_TOKEN']
CHAT_ID = os.environ['TELEGRAM_CHAT_ID']

def send_telegram(msg):
    url = f"https://api.telegram.org/bot{TOKEN}/sendMessage"
    data = {'chat_id': CHAT_ID, 'text': msg, 'parse_mode': 'Markdown'}
    requests.post(url, data=data)

def get_signal(sym):
    df = yf.download(sym + ".NS", period="5d", interval="5m", progress=False)
    if df.empty or len(df) < 50:
        return None
    df['SMA20'] = df['Close'].rolling(20).mean()
    df['SMA50'] = df['Close'].rolling(50).mean()
    df['RSI']   = ta.momentum.RSIIndicator(df['Close'], 14).rsi()
    r = df.iloc[-1]

    if r.RSI < 30 and r.SMA20 > r.SMA50:
        price = r.Close
        sl = price * 0.98
        tgt = price * 1.02
        return f"*{sym}* BUY @ ₹{price:.2f}\nSL: ₹{sl:.2f} | TG: ₹{tgt:.2f}"
    if r.RSI > 70 and r.SMA20 < r.SMA50:
        price = r.Close
        sl = price * 1.02
        tgt = price * 0.98
        return f"*{sym}* SELL @ ₹{price:.2f}\nSL: ₹{sl:.2f} | TG: ₹{tgt:.2f}"
    return None

def run():
    symbols = [
        'INFY','RELIANCE','TCS','HDFCBANK','ICICIBANK',
        # Add remaining NIFTY 200 tickers here
    ]
    for sym in symbols:
        msg = get_signal(sym)
        if msg:
            send_telegram(msg)

if __name__ == '__main__':
    run()
